wget http://www.statmt.org/de-news/de-news-v0.91.tar.gz
rm consolidate-corpus.perl README txt/de-news-*.de.* txt/*.al txt/*.pre
mv txt de_news_raw